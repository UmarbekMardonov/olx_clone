from rest_framework import serializers
from .models import CategoryBig
from django.utils.translation import gettext as _


class CategoryBigSerializer(serializers.ModelSerializer):
    class Meta:
        model = CategoryBig
        fields = ['id', 'title', 'categoryLittle']

    def validate_title(self, value):
        if len(value) < 5:
            raise serializers.ValidationError(_("Nom 5 ta harfdan ziyod bo'lishi kerak"))
        return value
