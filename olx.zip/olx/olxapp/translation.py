from modeltranslation.translator import translator, TranslationOptions
from .models import CategoryBig


class NewsTranslationOptions(TranslationOptions):
    fields = ('title',)


translator.register(CategoryBig, NewsTranslationOptions)
