from django.urls import path
from .views import CategoryBigList, CategoryBigCreate

urlpatterns = [
    path('ab/', CategoryBigList.as_view()),
    path('', CategoryBigCreate.as_view()),
]
