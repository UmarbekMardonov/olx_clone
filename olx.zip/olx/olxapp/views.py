from django.shortcuts import render
from rest_framework import generics
from .models import CategoryBig
from .serializers import CategoryBigSerializer
from django.utils.translation import get_language


class CategoryBigList(generics.ListAPIView):
    queryset = CategoryBig.objects.all()
    serializer_class = CategoryBigSerializer

    def get_queryset(self, *args, **kwargs):
        print(get_language())
        return self.queryset.filter(lan=get_language())


class CategoryBigCreate(generics.CreateAPIView):
    queryset = CategoryBig.objects.all()
    serializer_class = CategoryBigSerializer
