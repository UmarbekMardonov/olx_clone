from django.contrib import admin
from .models import CategoryBig, Ads, CategoryLittle


@admin.register(Ads)
class AdsAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'phone_number', 'image')


@admin.register(CategoryLittle)
class CategoryLittleAdmin(admin.ModelAdmin):
    list_display = ('id', 'title')


@admin.register(CategoryBig)
class CategoryBigAdmin(admin.ModelAdmin):
    list_display = ('id', 'title')
