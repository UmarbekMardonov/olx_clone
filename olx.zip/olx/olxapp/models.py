from datetime import datetime
from django.db import models
from django.db.models.functions import Coalesce
from django.contrib.gis.db import models
from django.db import models
from django.db.models import signals
from django.dispatch import receiver


class Language(models.Choices):
    en = 'en'
    ru = 'ru'
    uz = 'uz'


class CategoryManager(models.Manager):
    def with_count(self):
        return super().get_queryset().annotate(counts=models.Count("ads"))


class CategoryLittle(models.Model):
    title = models.CharField(max_length=220)
    objects = CategoryManager()
    ads_count = models.IntegerField()
    language = models.CharField(max_length=220, choices=Language.choices, default=Language.uz)


class SavdoTuri(models.Choices):
    money = 'pulga'
    free = 'tegin'
    obmen = 'obmen'


class LanguageC(models.Choices):
    en = 'en'
    uz = 'uz'


class CategoryBig(models.Model):
    title = models.CharField(max_length=220)
    lan = models.CharField(max_length=5, choices=LanguageC.choices, default=LanguageC.uz)
    categoryLittle = models.ForeignKey(CategoryLittle, on_delete=models.CASCADE)


class Ads(models.Model):
    title = models.ForeignKey(CategoryLittle, on_delete=models.CASCADE, related_name='ads')
    location = models.CharField(max_length=220, blank=True, null=True)
    phone_number = models.IntegerField(blank=True)
    email = models.EmailField(blank=True, null=True)
    description = models.CharField(max_length=500, blank=True, null=True)
    turi = models.CharField(max_length=220, choices=SavdoTuri.choices, default=SavdoTuri.money)
    price = models.IntegerField()
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)
    image = models.ImageField()


'''
class Region(models.Model):
    title = models.CharField(max_length=220)+



class District(models.Model):
    title = models.CharField(max_length=220)q
    region = models.ForeignKey(Region, on_delete=models.CASCADE)


class School(models.Model):
    title = models.CharField(max_length=220)
    region = models.ForeignKey(Region, on_delete=models.CASCADE)
    district = models.ForeignKey(District, on_delete=models.CASCADE)
    pupil = models.ForeignKey(Pupil, related_name='school')


class Pupil(models.Model):
    name = models.CharField(max_length=220)
    ball = models.IntegerField()
'''
