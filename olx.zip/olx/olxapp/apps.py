from django.apps import AppConfig


class OlxappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'olxapp'
